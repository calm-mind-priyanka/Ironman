import asyncio
import logging
import os
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from motor.motor_asyncio import AsyncIOMotorClient
from pyrogram import Client, idle

from config import Config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [%(levelname)s] - %(name)s - %(message)s",
)

logger = logging.getLogger("AutoFilterBot")
_bot_started = False

# Load only the real plugins.
# admin_actions.py is intentionally excluded because it duplicates admin.py.
PLUGIN_INCLUDE = [
    "start",
    "settings",
    "autofilter",
    "index",
    "search",
    "forcesub",
    "shortlink",
    "p_s_qr",
    "admin",
]


def validate_config():
    required = {
        "API_ID": Config.API_ID,
        "API_HASH": Config.API_HASH,
        "BOT_TOKEN": Config.BOT_TOKEN,
        "DATABASE_URI": Config.DATABASE_URI,
        "DATABASE_NAME": Config.DATABASE_NAME,
    }

    missing = [name for name, value in required.items() if not value]
    if missing:
        raise RuntimeError(
            "Missing required configuration: " + ", ".join(missing)
        )

    if not Config.DATABASE_URI_2:
        raise RuntimeError("DATABASE_URI_2 is missing")


async def check_databases():
    logger.info("🔌 Checking MongoDB connection 1...")
    client1 = AsyncIOMotorClient(
        Config.DATABASE_URI,
        serverSelectionTimeoutMS=8000,
        connectTimeoutMS=8000,
    )
    try:
        await client1.admin.command("ping")
        logger.info("✅ MongoDB connection 1 OK")
    finally:
        client1.close()

    if Config.DATABASE_URI_2 != Config.DATABASE_URI:
        logger.info("🔌 Checking MongoDB connection 2...")
        client2 = AsyncIOMotorClient(
            Config.DATABASE_URI_2,
            serverSelectionTimeoutMS=8000,
            connectTimeoutMS=8000,
        )
        try:
            await client2.admin.command("ping")
            logger.info("✅ MongoDB connection 2 OK")
        finally:
            client2.close()
    else:
        logger.info("ℹ️ DATABASE_URI_2 is the same as DATABASE_URI")


class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        status = 200 if _bot_started else 503
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(
            b"Telegram bot is running" if _bot_started
            else b"Telegram bot is starting"
        )

    def log_message(self, format, *args):
        return


def start_web_server():
    port = int(os.environ.get("PORT", "8000"))
    server = ThreadingHTTPServer(("0.0.0.0", port), HealthHandler)
    logger.info("🌐 Health server listening on port %s", port)
    server.serve_forever()


app = Client(
    "AutoFilterBot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    plugins={
        "root": "plugins",
        "include": PLUGIN_INCLUDE,
    },
)


async def main():
    global _bot_started

    logger.info("🔍 Checking configuration...")
    validate_config()
    logger.info("✅ Configuration OK")

    await check_databases()

    logger.info("🚀 Starting Pyrogram...")
    await app.start()

    _bot_started = True
    me = await app.get_me()
    logger.info("✅ Telegram bot started: @%s (%s)", me.username, me.id)
    logger.info("✅ Handlers loaded. Bot is ready.")

    try:
        await idle()
    finally:
        _bot_started = False
        await app.stop()
        logger.info("🛑 Telegram bot stopped.")


if __name__ == "__main__":
    logger.info("🤖 AutoFilterBot starting...")

    threading.Thread(
        target=start_web_server,
        daemon=True,
    ).start()

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Shutdown requested")
    except Exception:
        logger.critical("❌ Bot crashed", exc_info=True)
        sys.exit(1)
